"""
This file contains mock data for data pipeline - load's function's
testing 
"""
