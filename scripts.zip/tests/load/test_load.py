"""
Tests for data_pipeline's load functions
"""
