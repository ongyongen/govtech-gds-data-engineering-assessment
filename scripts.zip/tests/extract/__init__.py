"""
The tests data pipeline package consists of tests for the extract data processing
functions
"""

from .mocks import *
from .test_extract import *
